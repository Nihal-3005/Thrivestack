package com.sbtodo.serviceiml;

import org.springframework.beans.factory.annotation.Autowired;

import com.sbtodo.model.TodoApp;
import com.sbtodo.repository.Todorepository;
import com.sbtodo.service.ServiceI;

public class ServiceImpl implements ServiceI {
    
    @Autowired
    Todorepository tr;
    
	@Override
	public void saveData(TodoApp t) {
		tr.save(t);	
	}

	@Override
	public Iterable<TodoApp> getAllData() {
		
		return tr.findAll();
	}

}
