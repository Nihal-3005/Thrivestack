package com.sbtodo.service;


import com.sbtodo.model.TodoApp;

public interface ServiceI {
	
	public void saveData(TodoApp t);
	
	public Iterable<TodoApp> getAllData();
	

}
