package com.sbtodo.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sbtodo.model.TodoApp;
import com.sbtodo.service.ServiceI;

@Controller
public class TodoController {
	
	@Autowired
	ServiceI ti;
	
	@RequestMapping("/")
	public String AddNew()
	{
		return "AddNew";
	}
	
	@RequestMapping("/Save")
	public String saveData (@ModelAttribute TodoApp t)
	{
		ti.saveData(t);
		return "AddNew";
	}
	
	@RequestMapping("/ViewAllTask")
	public String loginSucess(Model m)
	{
		
			Iterable<TodoApp> tList=ti.getAllData();
			m.addAttribute("data",tList);
			return "ViewAllTask";
	}
	
}
