package com.sbtodo.repository;

import org.springframework.data.repository.CrudRepository;

import com.sbtodo.model.TodoApp;

public interface Todorepository extends CrudRepository <TodoApp , Integer> {

}
